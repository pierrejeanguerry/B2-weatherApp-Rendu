#define URL "http://51.159.188.157:8000/api/readings"
#define NAME "Station_2dVpjTaU"